# Link Demo Wiki Log

*Append-only record of demo wiki operations.*

---

## [2026-05-02T00:00:00Z] demo | create first-run sample wiki

- Source: raw/agent-memory-session.md
- Source: raw/transformer-reading-notes.md
- Source: raw/local-release-notes.md
- Created: sources/agent-memory-session.md
- Created: sources/transformer-reading-notes.md
- Created: sources/local-release-notes.md
- Created: concepts/agent-memory.md
- Created: concepts/retrieval-augmented-generation.md
- Created: concepts/transformers.md
- Created: concepts/local-first-software.md
- Created: concepts/knowledge-graph.md
- Created: entities/link.md
- Created: memories/prefer-local-personal-memory.md
- Created: memories/keep-answers-short-and-cite-wiki-sources.md
- Created: memories/keep-agent-memory-in-local-markdown.md
- Created: memories/local-viewer-runs-on-port-3000.md
- Created: explorations/why-link-helps-agents.md
- Rebuilt: wiki/_backlinks.json
- Pages touched: 14

---
## [2026-09-27T03:16:09Z] remember | Payments deploy day

- Created: memories/payments-deploy-day.md
- Type: decision
- Scope: user
- Visibility: private
- log_previous_hash: 0000000000000000000000000000000000000000000000000000000000000000
- log_entry_hash: a653b7c0e9e86ce14345fbe9f27e4d0bf6a6b60639344ce2978835da656cb8ef

---
## [2026-09-27T03:16:09Z] remember | Staging port

- Created: memories/staging-port.md
- Type: fact
- Scope: user
- Visibility: private
- log_previous_hash: a653b7c0e9e86ce14345fbe9f27e4d0bf6a6b60639344ce2978835da656cb8ef
- log_entry_hash: 4db3d45dff8842c3f0821ddea4e51d4a5241e308a13c532d0c17b4458853908b

---
## [2026-09-27T03:16:09Z] session-end | Captured proposal-only session end notes at raw/memory-captures/20260927T031609Z-session-end.md

- Source input: stdin
- Project: none
- Secret warnings: none
- Proposals: 1
- log_previous_hash: 4db3d45dff8842c3f0821ddea4e51d4a5241e308a13c532d0c17b4458853908b
- log_entry_hash: aaa1b4e65489273d0a4d84b0b49f9ef802aa4bb445aae9de6b94f01ba7fa838b

---
