# Link Demo Wiki Index

> Last updated: 2026-05-02 | 14 pages | 3 sources

## Categories

### concepts
- [[agent-memory]] - Durable, inspectable context for AI agents. growing - 2 sources - also: AI memory, agent context
- [[retrieval-augmented-generation]] - Retrieves external context before generation. seed - 1 source - also: RAG
- [[transformers]] - Attention-based model architecture behind modern LLM systems. seed - 1 source
- [[local-first-software]] - Keeps user data on disk in inspectable formats. growing - 2 sources
- [[knowledge-graph]] - Shows pages as nodes and wikilinks as edges. seed - 1 source

### entities
- [[link]] - Local-first wiki and MCP memory server for agents. growing - 2 sources - also: Link MCP

### memories
- [[prefer-local-personal-memory]] - User preference that Link should behave as local personal memory for agents. preference · user
- [[keep-answers-short-and-cite-wiki-sources]] - Reviewed style preference for answers built from Link context. preference · user
- [[keep-agent-memory-in-local-markdown]] - Reviewed decision that memory stays in local Markdown with no cloud sync. decision · project
- [[local-viewer-runs-on-port-3000]] - Reviewed fact about where the local viewer serves this wiki. fact · project
- [[payments-deploy-day]] - We deploy the payments service only on Tuesdays after standup. decision · user
- [[staging-port]] - The staging server listens on port 8443. fact · user

### sources
- [[agent-memory-session]] - Demo note on durable project context. high
- [[transformer-reading-notes]] - Demo note connecting transformers, retrieval, and memory. high
- [[local-release-notes]] - Demo note on Link surfaces and graph visibility. high

### explorations
- [[why-link-helps-agents]] - Filed answer explaining Link as durable agent memory.

## Recent

| Date | Operation | Pages Touched |
|------|-----------|---------------|
| 2026-05-02 | demo: create first-run sample wiki | 14 pages |
