---
type: memory
title: "Local viewer runs on port 3000"
memory_type: fact
scope: project
status: active
date_captured: "2026-05-02T00:00:00Z"
source: "demo"
review_status: reviewed
reviewed_at: "2026-05-02T00:00:00Z"
review_note: "Seeded as a reviewed demo fact."
tags: [memory, viewer, setup]
aliases: ["viewer port", "serve port"]
---

# Local viewer runs on port 3000

> **TLDR:** The local Link viewer serves this wiki at http://127.0.0.1:3000 by default.

## Memory

`lnk serve` binds the read-only local viewer for [[link]] to `127.0.0.1:3000`. It is loopback-only and needs no account or network access.

## Use This When

- Telling the user where to inspect a page, memory, or the graph.
- Debugging why the viewer is unreachable.

## Source

Seeded demo fact for the first-run wiki.
