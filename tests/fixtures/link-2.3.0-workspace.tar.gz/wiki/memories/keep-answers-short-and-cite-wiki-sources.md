---
type: memory
title: "Keep answers short and cite wiki sources"
memory_type: preference
scope: user
status: active
date_captured: "2026-05-02T00:00:00Z"
source: "demo"
review_status: reviewed
reviewed_at: "2026-05-02T00:00:00Z"
review_note: "Seeded as a reviewed demo preference."
tags: [memory, style, answers]
aliases: ["answer style", "response style"]
---

# Keep answers short and cite wiki sources

> **TLDR:** The user prefers short, direct answers that cite the wiki pages they came from.

## Memory

When answering from Link, keep responses short and point to the [[knowledge-graph]] pages behind each claim instead of repeating whole documents.

## Use This When

- Formatting any answer that uses Link context.
- Deciding how much wiki text to quote in a reply.

## Source

Seeded demo preference for the first-run wiki.
