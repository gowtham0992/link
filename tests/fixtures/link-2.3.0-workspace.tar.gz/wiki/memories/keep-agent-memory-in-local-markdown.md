---
type: memory
title: "Keep agent memory in local Markdown"
memory_type: decision
scope: project
status: active
date_captured: "2026-05-02T00:00:00Z"
source: "demo"
review_status: reviewed
reviewed_at: "2026-05-02T00:00:00Z"
review_note: "Seeded as a reviewed demo decision."
tags: [memory, decision, local-first]
aliases: ["local markdown decision", "no cloud sync"]
---

# Keep agent memory in local Markdown

> **TLDR:** The project decided agent memory stays in local Markdown files with no cloud sync.

## Memory

This project keeps durable agent memory in plain local Markdown under `wiki/`, following [[local-first-software]]. No cloud sync, no hosted memory profile, no embeddings service.

## Use This When

- An agent or teammate proposes syncing memory to a hosted service.
- Explaining where memory lives and how to audit it.

## Source

Seeded demo decision for the first-run wiki.
