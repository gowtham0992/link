---
type: memory
title: "Staging port"
memory_type: fact
scope: user
visibility: private
status: active
date_captured: "2026-09-27T03:16:09Z"
source: "fixture"
review_status: pending
review_after: "2027-09-27"
reviewed_at: ""
tags: [memory, fact]
---

# Staging port

> **TLDR:** The staging server listens on port 8443.

## Memory

The staging server listens on port 8443.

## Use This When

- An agent needs relevant user context for future work.
- A future answer depends on this fact.

## Source

fixture
